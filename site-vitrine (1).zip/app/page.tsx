import Image from "next/image"
import Link from "next/link"

import { Button } from "@/components/ui/button"
import { Navbar } from "@/components/navbar"
import { ProjectCard } from "@/components/project-card"
import { Skills } from "@/components/skills"
import { Education } from "@/components/education"
import { Contact } from "@/components/contact"
import { Footer } from "@/components/footer"

export default function Home() {
  return (
    <div className="flex min-h-screen flex-col">
      <Navbar />
      <main className="flex-1">
        {/* Hero Section */}
        <section className="w-full py-12 md:py-24 lg:py-32 bg-gradient-to-r from-slate-900 to-slate-800 text-white">
          <div className="container px-4 md:px-6">
            <div className="grid gap-6 lg:grid-cols-2 lg:gap-12 items-center">
              <div className="space-y-4">
                <h1 className="text-3xl font-bold tracking-tighter sm:text-5xl xl:text-6xl/none">Anthony Arozarena</h1>
                <h2 className="text-xl text-slate-300">Développeur Web Freelance</h2>
                <p className="max-w-[600px] text-slate-300 md:text-xl">
                  Étudiant en L2 Informatique passionné par le développement web et la création d'expériences numériques
                  innovantes.
                </p>
                <div className="flex flex-col gap-2 min-[400px]:flex-row">
                  <Button asChild size="lg" className="bg-teal-500 hover:bg-teal-600">
                    <Link href="#contact">Me contacter</Link>
                  </Button>
                  <Button variant="outline" size="lg" className="border-slate-300 text-white hover:bg-slate-700">
                    <Link href="#projects">Voir mes projets</Link>
                  </Button>
                </div>
              </div>
              <div className="mx-auto lg:ml-auto">
                <div className="relative w-[280px] h-[280px] sm:w-[350px] sm:h-[350px] rounded-full overflow-hidden border-4 border-teal-500">
                  <Image
                    alt="Anthony Arozarena"
                    className="object-cover"
                    fill
                    src="/placeholder.svg?height=350&width=350"
                    priority
                  />
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* About Section */}
        <section id="about" className="w-full py-12 md:py-24 lg:py-32">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center">
              <div className="space-y-2">
                <h2 className="text-3xl font-bold tracking-tighter sm:text-5xl">À propos de moi</h2>
                <p className="max-w-[900px] text-slate-500 md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                  Développeur web freelance et étudiant en deuxième année d'informatique, je combine mes études et ma
                  passion pour créer des solutions web sur mesure.
                </p>
              </div>
            </div>
            <div className="mx-auto max-w-3xl space-y-4 py-8 text-center sm:text-left">
              <p className="text-slate-700">
                Bonjour ! Je suis Anthony, développeur web freelance basé à [Ville]. Actuellement en L2 Informatique à
                l'Université de [Nom], je me spécialise dans la création de sites web et d'applications modernes et
                performantes.
              </p>
              <p className="text-slate-700">
                Ma double casquette d'étudiant et de freelance me permet d'être constamment à jour sur les dernières
                technologies et méthodologies du développement web, tout en acquérant une expérience pratique précieuse
                auprès de clients variés.
              </p>
              <p className="text-slate-700">
                Je suis particulièrement passionné par le développement front-end et la création d'interfaces
                utilisateur intuitives et accessibles. Mon objectif est de transformer vos idées en réalités numériques
                fonctionnelles et esthétiques.
              </p>
            </div>
          </div>
        </section>

        {/* Skills Section */}
        <Skills />

        {/* Projects Section */}
        <section id="projects" className="w-full py-12 md:py-24 lg:py-32 bg-slate-50">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center">
              <div className="space-y-2">
                <h2 className="text-3xl font-bold tracking-tighter sm:text-5xl">Mes Projets</h2>
                <p className="max-w-[900px] text-slate-500 md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                  Découvrez une sélection de mes réalisations récentes.
                </p>
              </div>
            </div>
            <div className="mx-auto grid max-w-5xl grid-cols-1 gap-6 py-12 md:grid-cols-2 lg:grid-cols-3">
              <ProjectCard
                title="E-commerce Responsive"
                description="Site de vente en ligne développé avec React et Node.js, intégrant une API de paiement et un système de gestion des stocks."
                tags={["React", "Node.js", "MongoDB", "Stripe"]}
                imageSrc="/placeholder.svg?height=300&width=400"
                link="#"
              />
              <ProjectCard
                title="Application de Gestion"
                description="Dashboard administratif pour une entreprise locale permettant la gestion des clients, des commandes et des factures."
                tags={["Vue.js", "Firebase", "Tailwind CSS"]}
                imageSrc="/placeholder.svg?height=300&width=400"
                link="#"
              />
              <ProjectCard
                title="Portfolio Photographe"
                description="Site vitrine pour un photographe professionnel avec galerie dynamique et système de réservation de séances."
                tags={["Next.js", "Prisma", "PostgreSQL"]}
                imageSrc="/placeholder.svg?height=300&width=400"
                link="#"
              />
              <ProjectCard
                title="Blog Tech"
                description="Plateforme de blog avec système de gestion de contenu personnalisé et fonctionnalités de commentaires."
                tags={["WordPress", "PHP", "MySQL", "JavaScript"]}
                imageSrc="/placeholder.svg?height=300&width=400"
                link="#"
              />
              <ProjectCard
                title="Application Météo"
                description="Application web et mobile affichant les prévisions météorologiques en temps réel grâce à l'API OpenWeatherMap."
                tags={["React Native", "Redux", "API REST"]}
                imageSrc="/placeholder.svg?height=300&width=400"
                link="#"
              />
              <ProjectCard
                title="Jeu Éducatif"
                description="Jeu interactif pour enfants développé dans le cadre d'un projet universitaire visant à enseigner les bases de la programmation."
                tags={["JavaScript", "Canvas", "HTML5", "CSS3"]}
                imageSrc="/placeholder.svg?height=300&width=400"
                link="#"
              />
            </div>
          </div>
        </section>

        {/* Education Section */}
        <Education />

        {/* Contact Section */}
        <Contact />
      </main>
      <Footer />
    </div>
  )
}
